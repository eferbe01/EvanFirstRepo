Evan Ferber
Comp 20, Spring 2013
Assignment 5

I believe all aspects of the program work.  The APIs included are the get '/', the post '/submit.json', the get '/highscores.json', the get and post '/usersearch.  

I worked with Brett Cadigan on several parts of the assignment.  I've spent approximately 10 -15 hours on this project.  