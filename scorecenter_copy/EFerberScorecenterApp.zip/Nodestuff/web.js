
var express = require('express');
var app = express();
app.use(express.bodyParser());
app.set('title', 'ScoreCenterApp');

// Mongo initialization
var mongo = require('mongodb');
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  "mongodb://localhost/scorecenter";
  //<eferbe01>:<20comp2013>@dharma.mongohq.com:10093/scorecenter

var db = mongo.Db.connect(mongoUri,function (error, databaseConnection) {
	db = databaseConnection;
});


//CORS code below
app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.post('/submit.json', function(request, response) {
	
	if(!request.body.game_title)
	{
		response.send("Game title is invalid");
	}
	else if(!request.body.username)
	{
		response.send("Username is invalid");
	}
	else if(!parseInt(request.body.score))
	{
		response.send("Score is invalid");	
	}
	else
	{
		var info = {"game_title":"", "username":"", "score":"", "created_at":""};
		info.game_title=request.body.game_title;
		info.username=request.body.username;
		info.score=parseInt(request.body.score);
		info.created_at=new Date();
		console.log(info);
		db.collection('scores', function (err, scores){
			if (err)
				response.send("error inserting");
			else
			{
				scores.insert(info, {safe:true}, function (err, result){
					if(err)
					{
						response.send("error");
					}
					else
					{
						console.log("mongo inserted");
						response.send(result[0]);
					}
				});
			}
		});
	}
});

app.get('/', function(request, response) {
	response.set('Content-Type', 'text/html');
    html = '<!DOCTYPE html><html><head><title>ScoreCenter</title><script src="http://code.jquery.com/jquery-1.9.1.min.js"></script></head><body>';
   	html += '<body><h1><center>Table of Highscores</center></h1><hr><table id="scoresTable" border="1" width="100%"><thead><tr><th>Game Title</th><th>Username</th><th>Score</th><th>Created At</th></tr></thead><tbody>';
    
	db.collection('scores', function(err, collection) {
		if(!err)
		{
			var rVal=collection.find().toArray(function(err,items){
				if(!err)
				{
					for(var i=0;i<items.length;i++)
					{	
						html+='<tr><td>'+items[i].game_title+'</td>'
						html+='<td>'+items[i].username+'</td>'
						html+='<td>'+items[i].score+'</td>'
						html+='<td>'+items[i].created_at+'</td></tr>'
					}
					html += '</tbody></table></body></html>';
    				response.send(html);
				}  
			});
		}
	});
});
  
app.get('/highscores.json', function(request, response) {
	db.collection('scores', function(err, collection) {
		if(!err)
		{
			var gameT=request.query.game_title;
			var rVal=collection.find({game_title:gameT}).sort({score:-1}).limit(10).toArray(function(err,items){
				//console.log(rVal);
				response.send(items);   
			});			
		}
	});
});
    
app.get('/usersearch', function(request, response) {
	response.set('Content-Type', 'text/html');
    html = '<!DOCTYPE html><html><head><title>User Search</title></head><body>';
   	html += '<h3><center>User Search for High Scores</center></h3><hr>';
   	html += '<form name ="search" id="usersearch" action="/usersearch" method="post"><input type="text" name="username" id="input" placeholder="Enter username here"><input type="submit" id="submit" value="SEARCH!"></form>';

	html += '</body></html>';
    response.send(html);
//response.send("Hello World!!!");
});
   
app.post('/usersearch',function(request,response){
	db.collection('scores',function(err,scores){
		if(!err)
		{
			scores.find().toArray(function(err,items){
				var html = '<!DOCTYPE html><html><head><title>User Search</title></head><body>';
  		 		html += '<h3><center>User Search for High Scores</center></h3><hr>';
  		 		html += '<form name ="search" id="usersearch" action="/usersearch" method="post"><input type="text" name="username" id="input" placeholder="Enter username here"><input type="submit" id="submit" value="SEARCH!"></form>';
   				html += '<table id="scoresTable" border="1" width="100%"><thead><tr><th>Game Title</th><th>Username</th><th>Score</th><th>Created At</th></tr></thead><tbody>';
    			for(var i=0;i<items.length;i++)
				{	
					if(items[i].username==request.body.username)
					{
						html+='<tr><td>'+items[i].game_title+'</td>'
						html+='<td>'+items[i].username+'</td>'
						html+='<td>'+items[i].score+'</td>'
						html+='<td>'+items[i].created_at+'</td></tr>'
					}
				}
				html += '</tbody></table></body></html>';
    			response.send(html);
			});
		}
	});
});
//app post usersearch, whatever user is searched for, return json with user info
//request.param


var port = process.env.PORT || 5000;
app.listen(port, function() {
	console.log("Listening on " + port);
    });
    
    